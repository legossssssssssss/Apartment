package com.example.dwell.Admin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.example.dwell.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import androidx.appcompat.app.AlertDialog

import com.google.firebase.database.ValueEventListener

class Visitor : AppCompatActivity() {
    private lateinit var saveButton: Button
    private lateinit var nameEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var addressEditText: EditText
    private lateinit var fromDateEditText: EditText
    private lateinit var toDateEditText: EditText
    private lateinit var flatNo:EditText
    private lateinit var blockNo:EditText
    private lateinit var ownername:EditText
    private lateinit var uniqcode:String
    private lateinit var progress: ProgressBar
    private lateinit var ownernumber:String
    private lateinit var buildingcode:String
    private lateinit var uniqueCodeEditText:EditText
    private lateinit var block:String
    private lateinit var apart:String
    private lateinit var username:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visitor)


        ownernumber=intent.getStringExtra("ownermobile").toString()
        buildingcode=intent.getStringExtra("code").toString()
        uniqcode=intent.getStringExtra("uniq").toString()




        saveButton = findViewById(R.id.okbutton)
        nameEditText = findViewById(R.id.username)
        phoneEditText = findViewById(R.id.phonetxt)
        addressEditText = findViewById(R.id.usermail)
        fromDateEditText = findViewById(R.id.usercardnumber)
        flatNo=findViewById(R.id.flatnumber)
        blockNo=findViewById(R.id.userblock)
        ownername=findViewById(R.id.ownername)
        toDateEditText = findViewById(R.id.todatetxt)
        progress=findViewById(R.id.progressBar)
        uniqueCodeEditText=findViewById(R.id.uniquecode)

        fetchData()




    }

    private fun fetchData() {
        progress.visibility=View.VISIBLE

        val database = FirebaseDatabase.getInstance()
        val gatePassRef = database.reference.child("Users")
            .child(ownernumber)
            .child("Buildings").child(buildingcode)
            .child("GatePasses")
            .child(uniqcode)

        gatePassRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val name = snapshot.child("Name").value.toString()
                    val phoneNumber = snapshot.child("PhoneNumber").value.toString()
                    val email = snapshot.child("Email").value.toString()
                    val fromDate = snapshot.child("FromDate").value.toString()
                    val toDate = snapshot.child("ToDate").value.toString()
                    val ownerName=snapshot.child("OwnerName").value.toString()
                    val flat=snapshot.child("Flat").value.toString()
                    val block=snapshot.child("Block").value.toString()

                    nameEditText.setText(name)
                    phoneEditText.setText(phoneNumber)
                    addressEditText.setText(email)
                    fromDateEditText.setText(fromDate)
                    toDateEditText.setText(toDate)
                    blockNo.setText(block)
                    flatNo.setText(flat)
                    ownername.setText(ownerName)
                    uniqueCodeEditText.setText(uniqcode)
                    progress.visibility=View.INVISIBLE

                } else {
                    progress.visibility=View.VISIBLE
                   // Toast.makeText(this@Visitor, "Invalid code", Toast.LENGTH_LONG).show()
                    showInvalidDialog()
                }
            }

            override fun onCancelled(error: DatabaseError) {
              //  Toast.makeText(this@Visitor, error.message, Toast.LENGTH_SHORT).show()
                progress.visibility=View.INVISIBLE
                // Handle error
            }
        })

    }

    private fun showInvalidDialog() {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.apply {
            setTitle("Invalid Code")
            setMessage("The provided code is invalid.")
            setPositiveButton("Close") { dialog, _ ->
                dialog.dismiss()
                finish()
            }
        }
        val dialog = dialogBuilder.create()
        dialog.show()
    }


}