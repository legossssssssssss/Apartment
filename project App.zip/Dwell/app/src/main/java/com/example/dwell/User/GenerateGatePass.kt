package com.example.dwell.User

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import androidx.core.content.ContextCompat
import com.example.dwell.R
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

class GenerateGatePass : AppCompatActivity() {

    private lateinit var saveButton: Button
    private lateinit var nameEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var addressEditText: EditText
    private lateinit var fromDateEditText: EditText
    private lateinit var toDateEditText: EditText
    private lateinit var uniqcode:String
    private lateinit var progress:ProgressBar
    private lateinit var owner:String
    private lateinit var buildingcode:String
    private lateinit var block:String
    private lateinit var apart:String
    private lateinit var username:String
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generate_gate_pass)

        saveButton = findViewById(R.id.okbutton)
        nameEditText = findViewById(R.id.username)
        phoneEditText = findViewById(R.id.phonetxt)
        addressEditText = findViewById(R.id.usermail)
        fromDateEditText = findViewById(R.id.usercardnumber)
        toDateEditText = findViewById(R.id.todatetxt)
        progress=findViewById(R.id.progressBar)

        owner=intent.getStringExtra("phoneNumber").toString()
        buildingcode=intent.getStringExtra("code").toString()
        block=intent.getStringExtra("block").toString()
        apart=intent.getStringExtra("apart").toString()
        username=intent.getStringExtra("username").toString()

        toDateEditText.setOnClickListener {
            showDatePickerDialog(toDateEditText)
        }
        fromDateEditText.setOnClickListener {
            showDatePickerDialog(fromDateEditText)
        }

        uniqcode=getUniqueCode()

        saveButton.setOnClickListener {
            if (validateFields()) {
                // Proceed with further action

                saveDataToRealtimeDatabase(uniqcode)


            } else {
               // showToast("Fill all details")
            }
        }
    }

    private fun saveDataToRealtimeDatabase(uniqueCode: String) {
        progress.visibility=View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val usersRef = database.reference.child("Users")
            .child(owner)
            .child("Buildings").child(buildingcode)
            .child("GatePasses")
            .child(uniqueCode)

        val name = nameEditText.text.toString()
        val phoneNumber = phoneEditText.text.toString()
        val address = addressEditText.text.toString()
        val fromDate = fromDateEditText.text.toString()
        val toDate = toDateEditText.text.toString()

        val gatePassData = HashMap<String, String>()
        gatePassData["Name"] = name
        gatePassData["PhoneNumber"] = phoneNumber
        gatePassData["Email"] = address
        gatePassData["FromDate"] = fromDate
        gatePassData["ToDate"] = toDate
        gatePassData["Block"]=block
        gatePassData["Flat"]=apart
        gatePassData["OwnerName"]=username
        gatePassData["uniqcode"]=uniqcode

        usersRef.setValue(gatePassData)
            .addOnSuccessListener {
                //showToast("Data saved successfully!")

                addUnderHim(uniqueCode)
            }
            .addOnFailureListener {
                progress.visibility=View.INVISIBLE
               // showToast("Failed to save data.")
            }
    }

    private fun addUnderHim(uniqueCode: String) {

        val database2 = FirebaseDatabase.getInstance()
        val usersRef2 = database2.reference.child("Users")
            .child(owner)
            .child("Buildings")
            .child(buildingcode)
            .child("blocks")
            .child(block)
            .child(apart)
            .child("GatePasses")
            .child(uniqueCode)

        val name = nameEditText.text.toString()
        val phoneNumber = phoneEditText.text.toString()
        val address = addressEditText.text.toString()
        val fromDate = fromDateEditText.text.toString()
        val toDate = toDateEditText.text.toString()

        val gatePassData = HashMap<String, String>()
        gatePassData["Name"] = name
        gatePassData["PhoneNumber"] = phoneNumber
        gatePassData["Address"] = address
        gatePassData["FromDate"] = fromDate
        gatePassData["ToDate"] = toDate
        gatePassData["Block"]=block
        gatePassData["Flat"]=apart
        gatePassData["OwnerName"]=username
        gatePassData["uniqcode"]=uniqcode

        usersRef2.setValue(gatePassData)
            .addOnSuccessListener {
               // showToast("Data saved successfully!")
                progress.visibility=View.INVISIBLE
                val intent = Intent(this, QrGenerator::class.java)
                intent.putExtra("uniq",uniqueCode)
                startActivity(intent)
                finish()

            }
            .addOnFailureListener {
                progress.visibility=View.INVISIBLE
               // showToast("Failed to save data.")
            }

    }


    private fun validateFields(): Boolean {
        // Validate all fields
        if (nameEditText.text.toString().isEmpty() ||
            phoneEditText.text.toString().isEmpty() ||
            addressEditText.text.toString().isEmpty() ||
            fromDateEditText.text.toString().isEmpty() ||
            toDateEditText.text.toString().isEmpty()
        ) {
            return false
        }
        return true
    }

    private fun showToast(message: String) {
       // Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun getUniqueCode(): String {
        val characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return (0 until 8)
            .map { characters[Random.nextInt(characters.length)] }
            .joinToString("")
    }
    private fun showDatePickerDialog(deadlineEditText: EditText) {
        val currentDate = Calendar.getInstance()
        val year = currentDate.get(Calendar.YEAR)
        val month = currentDate.get(Calendar.MONTH)
        val day = currentDate.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(selectedYear, selectedMonth, selectedDay)

                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val formattedDate = dateFormat.format(selectedDate.time)

                deadlineEditText.setText(formattedDate)
            },
            year,
            month,
            day
        )

        // Set minimum date to current date
        datePickerDialog.datePicker.minDate = currentDate.timeInMillis

        datePickerDialog.show()

        // Access the buttons of the DatePickerDialog and set their text color
        val positiveButton = datePickerDialog.getButton(DatePickerDialog.BUTTON_POSITIVE)
        positiveButton.setTextColor(ContextCompat.getColor(this, R.color.black))

        val negativeButton = datePickerDialog.getButton(DatePickerDialog.BUTTON_NEGATIVE)
        negativeButton.setTextColor(ContextCompat.getColor(this, R.color.black))
    }






}