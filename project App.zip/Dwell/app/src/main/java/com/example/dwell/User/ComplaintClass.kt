package com.example.dwell.User

data class ComplaintClass(val blocknumber: String = "", val apartnumber: String = "", val complaintheading: String = "",val subheading: String = "",val complaintDescription: String = "",val complaintdate: String = "")