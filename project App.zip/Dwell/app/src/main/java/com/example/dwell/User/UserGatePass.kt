package com.example.dwell.User

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class UserGatePass : AppCompatActivity() {

    private lateinit var add:TextView
    private lateinit var back:TextView
    private lateinit var recyclerview: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var gateAdapter: GatePassAdapter
    private lateinit var owner:String
    private lateinit var buildingcode:String
    private lateinit var block:String
    private lateinit var apart:String
    private lateinit var username:String
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_gate_pass)

        owner=intent.getStringExtra("phoneNumber").toString()
        buildingcode=intent.getStringExtra("code").toString()
        block=intent.getStringExtra("block").toString()
        apart=intent.getStringExtra("apart").toString()
        username=intent.getStringExtra("username").toString()

        add=findViewById(R.id.add)
        back=findViewById(R.id.back)
        recyclerview = findViewById(R.id.recyler)
        progress = findViewById(R.id.progressBarComp)

        fetchdata()

       gateAdapter = GatePassAdapter(ArrayList())

        // Set billAdapter to RecyclerView
        recyclerview.adapter =gateAdapter

        add.setOnClickListener {
            val intent=Intent(this,GenerateGatePass::class.java)
            intent.putExtra("phoneNumber",owner)
            intent.putExtra("code",buildingcode)
            intent.putExtra("block",block)
            intent.putExtra("apart",apart)
            intent.putExtra("username",username)
            startActivity(intent)
        }

        back.setOnClickListener {
            finish()
        }


    }
    private fun fetchdata() {
        progress.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val billsReference = database.getReference("Users")
            .child(owner) // Replace with your specific user phone number
            .child("Buildings")
            .child(buildingcode) // Replace with your specific building code
            .child("blocks")
            .child(block)
            .child(apart)
            .child("GatePasses")
        billsReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val billsList = ArrayList<GatePassData>()
                for (billSnapshot in snapshot.children) {
                    val bill = billSnapshot.getValue(GatePassData::class.java)
                    bill?.let {

                        billsList.add(bill)
                    }
                }

                recyclerview.layoutManager = LinearLayoutManager(this@UserGatePass) // Change this line
                gateAdapter.add(billsList) // Change this line
                progress.visibility = View.INVISIBLE

            }

            override fun onCancelled(error: DatabaseError) {
               // Toast.makeText(this@UserGatePass, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()
                progress.visibility = View.GONE
            }
        })
    }
}