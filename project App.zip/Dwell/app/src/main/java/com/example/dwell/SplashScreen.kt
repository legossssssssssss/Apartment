package com.example.dwell

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class SplashScreen : AppCompatActivity() {
    private var SPLASH_TIMEOUT = 1000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        Handler().postDelayed({ // Create an Intent to start the MainActivity
            val intent = Intent(this@SplashScreen, MainActivity::class.java)

            // Start the MainActivity
            startActivity(intent)

            // Finish the current activity
            finish()
        }, SPLASH_TIMEOUT.toLong())
    }
}