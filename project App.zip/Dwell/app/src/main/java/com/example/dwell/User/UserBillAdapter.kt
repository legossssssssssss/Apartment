package com.example.dwell.User

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Calendar

class UserBillAdapter(private var billList: List<BillPaidData>, private val apartment: String) : RecyclerView.Adapter<UserBillAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val billTitle: TextView = itemView.findViewById(R.id.billheading)
        private val billDescription: TextView = itemView.findViewById(R.id.billdescription)
        private val deadline: TextView = itemView.findViewById(R.id.deadline)
        private val price: TextView = itemView.findViewById(R.id.pricett)
        private val block: TextView = itemView.findViewById(R.id.block)
        private val status: TextView = itemView.findViewById(R.id.billstatus)

// Use the retrieved values as needed


        fun bind(bill: BillPaidData) {
            billTitle.text = bill.title
            billDescription.text = bill.description
            deadline.text = bill.deadline
            price.text = "₹" + bill.price
            block.text = bill.block
            status.text = bill.status
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.bill_item_user, parent, false)
        val viewHolder = ViewHolder(view)
        view.setOnClickListener {
            val position = viewHolder.adapterPosition

            if (position != RecyclerView.NO_POSITION) {
                // Get the bill at the clicked position
                val bill = billList[position]

                // Open dialog with custom layout
                showDialog(view.context, bill)
            }
        }
        return viewHolder
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(billList[position])
    }

    override fun getItemCount(): Int {
        return billList.size
    }

    fun add(bills: List<BillPaidData>) {
        billList = bills
        notifyDataSetChanged()
    }

    @SuppressLint("MissingInflatedId", "SuspiciousIndentation")
    private fun showDialog(context: Context, bill: BillPaidData) {
        // Inflate your custom dialog layout
        val dialogView = LayoutInflater.from(context).inflate(R.layout.user_pay_bill, null)

        val builder = AlertDialog.Builder(context)
        builder.setView(dialogView)
        builder.setPositiveButton("Close") { dialog, _ ->
            dialog.dismiss()
        }
        val dialog = builder.create()

        val progress = dialogView.findViewById<ProgressBar>(R.id.progressBarBill)
        val pay = dialogView.findViewById<Button>(R.id.pay)

        if(bill.status=="paid"){
            pay.visibility=View.INVISIBLE
        }

        // Customize your dialog view (e.g., set bill details)
        val billtitle = dialogView.findViewById<EditText>(R.id.billtitle)
        billtitle.setText(bill.title)

        val billdescription = dialogView.findViewById<EditText>(R.id.billdescription)
        billdescription.setText(bill.description)

        val billdeadline = dialogView.findViewById<EditText>(R.id.deadlinedate)
        billdeadline.setText(bill.deadline)

        val billblock = dialogView.findViewById<EditText>(R.id.blocknm)
        billblock.setText(bill.block)

        val billprice = dialogView.findViewById<EditText>(R.id.price)
        billprice.setText(bill.price)

        progress.visibility = View.INVISIBLE

        val displayMetrics = context.resources.displayMetrics
        val dialogWidth = (displayMetrics.widthPixels * 0.9).toInt() // 90% of screen width
        val dialogHeight = (displayMetrics.heightPixels * 0.9).toInt() // 90% of screen height
        dialogView.layoutParams = ViewGroup.LayoutParams(dialogWidth, dialogHeight)

        val apartm = apartment

        pay.setOnClickListener {
            progress.visibility = View.VISIBLE
            val paiddate = getCurrentDate()
            val database = FirebaseDatabase.getInstance()
            val reference = database.getReference("Users")
                .child(bill.owner) // Replace with your specific user phone number
                .child("Buildings")
                .child(bill.buildingcode) // Replace with your specific building code
                .child("Bills")
                .child("Block"+bill.block)
                .child(bill.key)
                .child("paid")
                .child(apartm)
                reference.setValue(paiddate)
                .addOnSuccessListener {
                    // Check if the apartment exists under pending and remove it if it exists
                    val pendingRef = database.getReference("Users")
                        .child(bill.owner)
                        .child("Buildings")
                        .child(bill.buildingcode)
                        .child("Bills")
                        .child("Block"+bill.block)
                        .child(bill.key)
                        .child("pending")
                        .child(apartm)

                    pendingRef.addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            if (snapshot.exists()) {
                                snapshot.ref.removeValue()
                                    .addOnSuccessListener {
                                        progress.visibility = View.INVISIBLE
                                        chanepay(bill,bill.key,apartm)
                                       // Toast.makeText(context, "Apartment $apartm removed from pending.", Toast.LENGTH_SHORT).show()

                                        // Dismiss the dialog after showing Toast message
                                        dialog.dismiss()
                                    }
                                    .addOnFailureListener { e ->
                                        progress.visibility = View.INVISIBLE
                                       // Toast.makeText(context, "Failed to remove apartment $apartm from pending: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            progress.visibility = View.INVISIBLE
                           // Toast.makeText(context, "Error checking pending: ${error.message}", Toast.LENGTH_SHORT).show()
                        }
                    })
                }
        }

        // Create and show the dialog
        dialog.setOnShowListener {
            val positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

            // Set text color to black
            positiveButton.setTextColor(ContextCompat.getColor(context, android.R.color.black))
            negativeButton.setTextColor(ContextCompat.getColor(context, android.R.color.black))

            // Set background to black_button_background drawable
            positiveButton.setBackgroundResource(R.drawable.black_button_background)
            negativeButton.setBackgroundResource(R.drawable.black_button_background)
        }
        dialog.show()
    }

    private fun getCurrentDate(): String {
        val currentDate = Calendar.getInstance()
        val day = currentDate.get(Calendar.DAY_OF_MONTH)
        val month = currentDate.get(Calendar.MONTH) + 1 // Months are zero-based in Calendar, so add 1
        val year = currentDate.get(Calendar.YEAR)
        return "$day/$month/$year"
    }

    private fun chanepay(bill: BillPaidData, billKey: String, apartm: String) {
        val database = FirebaseDatabase.getInstance()
        val statusRef = database.getReference("Users")
            .child(bill.owner) // Replace with your specific user phone number
            .child("Buildings")
            .child(bill.buildingcode) // Replace with your specific building code
            .child("blocks")
            .child("Block"+bill.block)
            .child(apartm)
            .child("bills")
            .child(billKey)
            .child("status")
        statusRef.setValue("paid")
            .addOnSuccessListener {

                // If payment status is updated successfully
                // Toast.makeText(context, "Payment status updated to paid.", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                // If there's any error updating the payment status
                // Toast.makeText(context, "Failed to update payment status: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
