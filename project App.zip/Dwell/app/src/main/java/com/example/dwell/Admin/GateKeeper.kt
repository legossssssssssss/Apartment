package com.example.dwell.Admin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.cardview.widget.CardView
import com.example.dwell.R
import com.google.firebase.database.*
import com.google.zxing.integration.android.IntentIntegrator

class GateKeeper : AppCompatActivity() {

    private lateinit var scan: CardView
    private lateinit var verify: CardView

    private lateinit var buildingcode: String
    private lateinit var mobile: String
    private lateinit var scannedCode: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gate_keeper)

        scan = findViewById(R.id.scanner)
        verify = findViewById(R.id.verifycode)

        buildingcode = intent.getStringExtra("buildingCode").toString()
        mobile = intent.getStringExtra("owner").toString()

        scan.setOnClickListener {
            startScanner()
        }
        verify.setOnClickListener {
            showDialog()
        }
    }

    private fun showDialog() {
        val dialogBuilder = AlertDialog.Builder(this)
        val layout = LinearLayout(this)
        val layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        layout.layoutParams = layoutParams
        layout.orientation = LinearLayout.VERTICAL

        val editText = EditText(this)
        editText.hint = "Enter Code"
        layout.addView(editText)

        dialogBuilder.apply {
            setTitle("Enter Verification Code")
            setView(layout)
            setPositiveButton("Submit") { dialog, which ->
                val enteredCode = editText.text.toString()
                // Perform actions with the entered code
                if (enteredCode.isNotEmpty()) {
                    // Call a function or do something with the entered code
                  //  Toast.makeText(this@GateKeeper, "Code submitted: $enteredCode", Toast.LENGTH_SHORT).show()
                    checkCodeInDataBase(enteredCode)
                } else {
                    //Toast.makeText(this@GateKeeper, "Please enter a code", Toast.LENGTH_SHORT).show()
                }
            }
            setNegativeButton("Cancel") { dialog, which ->
                dialog.dismiss()
            }
        }

        val dialog = dialogBuilder.create()
        dialog.show()
    }

    private fun checkCodeInDataBase(code: String) {
        val intent = Intent(this@GateKeeper, Visitor::class.java).apply {

            putExtra("ownermobile",mobile)
            putExtra("code",buildingcode)
            putExtra("uniq",code)
        }
        startActivity(intent)

    }

    private fun startScanner() {
        val integrator = IntentIntegrator(this)
        integrator.setPrompt("Scan a QR code")
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
        integrator.setCameraId(0)  // Use the rear camera
        integrator.setBeepEnabled(true)
        integrator.setBarcodeImageEnabled(true)
        integrator.initiateScan()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents == null) {
                // If QR code scanning is canceled
               // Toast.makeText(this, "Scan canceled", Toast.LENGTH_SHORT).show()
            } else {
                // If QR code is scanned successfully
                scannedCode = result.contents.toString()
                checkCodeInDataBase(scannedCode)
                //Toast.makeText(this, "Scanned: ${result.contents}", Toast.LENGTH_SHORT).show()
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
