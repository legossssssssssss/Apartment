package com.example.dwell

data class AdminprofileClass(
    val name: String? = "",
    val state: String? = "",
    val pincode: String? = "",
    val city: String? = "",
    val address: String? = "",
    val phone: String? = ""
)