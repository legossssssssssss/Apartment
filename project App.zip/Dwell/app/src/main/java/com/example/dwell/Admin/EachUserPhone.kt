package com.example.dwell.Admin

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.dwell.R
import com.google.firebase.database.*
import kotlin.math.max

class EachUserPhone : AppCompatActivity() {
    private lateinit var mobilenum: String
    private lateinit var buildingCode: String
    private lateinit var maxUnits: String
    private lateinit var totalFloors: String
    private lateinit var container: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var blockButtonName: String

    private var currentColorIndex = 0
    private lateinit var alertDialog: AlertDialog // Declare alertDialog at class level

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_each_user_phone)

        mobilenum = intent.getStringExtra("mobile").toString()
        buildingCode = intent.getStringExtra("code").toString()
        maxUnits = intent.getStringExtra("maxunits").toString()
        totalFloors = intent.getStringExtra("totalfloors").toString()
        blockButtonName = intent.getStringExtra("blockbutton").toString()

        progress = findViewById(R.id.progressBar)
        container = findViewById<LinearLayout>(R.id.container)


        getrowsandcolumns()



        checkInData()
    }

    private fun getrowsandcolumns() {
        progress.visibility=View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users")
            .child(mobilenum) // Replace with your specific user phone number
            .child("Buildings")
            .child(buildingCode) // Replace with your specific building code
            .child("blocks")
            .child(blockButtonName)
            .child("Details")

        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    val details = dataSnapshot.value as? Map<String, Any>
                    if (details != null) {
                        maxUnits = details["maxunits"].toString() // Update maxUnits from Firebase
                        totalFloors = details["totalfloors"].toString() // Update totalFloors from Firebase
                        // Now you have both maxUnits and totalFloors, you can use them as needed
                        progress.visibility=View.INVISIBLE
                        generateButtons(totalFloors.toInt(), maxUnits.toInt(), container)
                        //Toast.makeText(this@EachUserPhone,maxUnits+totalFloors,Toast.LENGTH_SHORT).show()
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                progress.visibility=View.INVISIBLE
                // Handle error
               // Toast.makeText(this@EachUserPhone, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }



    private fun generateButtons(number: Int, number2: Int, container: LinearLayout) {
        for (i in number downTo 1) {
            val rowLayout = LinearLayout(this)
            rowLayout.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rowLayout.orientation = LinearLayout.HORIZONTAL

            for (j in 0 until number2) {
                val button = Button(this)
                button.layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )

                if (i == 1) {
                    button.text = "G${j + 1}"
                } else {
                    button.text = "${i - 1}0${j + 1}" // Button label
                }

                button.setBackgroundColor(Color.parseColor("#00000000")) // Initial color transparent

                button.setOnClickListener {
                    openDialogData(button.text.toString())
                }

                rowLayout.addView(button)
            }

            container.addView(rowLayout)
        }
    }


    private fun openDialogData(buttonName: String) {
        val dialogBuilder = AlertDialog.Builder(this)
        val inflater = layoutInflater
        val dialogView = inflater.inflate(R.layout.user_profile, null)
        dialogBuilder.setView(dialogView)

        val nameEditText = dialogView.findViewById<EditText>(R.id.name)
        val mobileEditText = dialogView.findViewById<EditText>(R.id.mobile)
        val passEditText = dialogView.findViewById<EditText>(R.id.pass)
        val saveButton = dialogView.findViewById<Button>(R.id.saveButton)
        val editButton = dialogView.findViewById<Button>(R.id.EditButton)
        val progressBar = dialogView.findViewById<ProgressBar>(R.id.progressBar)

        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users")
            .child(mobilenum) // Replace with your specific user phone number
            .child("Buildings")
            .child(buildingCode) // Replace with your specific building code
            .child("blocks")
            .child(blockButtonName)
            .child(buttonName)






        progressBar.visibility = ProgressBar.VISIBLE // Show progress bar

        // Check if user data exists under the button name
        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                progressBar.visibility = ProgressBar.GONE // Hide progress bar

                if (dataSnapshot.exists()) {
                    // User data exists, display it and disable EditText fields
                    val userData = dataSnapshot.getValue(UserData::class.java)
                    if (userData != null) {
                        nameEditText.setText(userData.username)
                        mobileEditText.setText(userData.mobile)
                        passEditText.setText(userData.password)

                        if (userData.username.isEmpty() || userData.mobile.isEmpty() || userData.password.isEmpty() ){
                            nameEditText.isEnabled = true
                            mobileEditText.isEnabled = true
                            passEditText.isEnabled = true

                            saveButton.visibility = View.VISIBLE
                            editButton.visibility = View.INVISIBLE
                            nameEditText.requestFocus()



                        }
                        else{
                            nameEditText.isEnabled = false
                            mobileEditText.isEnabled = false
                            passEditText.isEnabled = false

                            saveButton.visibility = View.INVISIBLE
                            editButton.visibility = View.VISIBLE
                        }


                    }
                }
                else {
                   // Toast.makeText(this@EachUserPhone, "No Data Found", Toast.LENGTH_SHORT).show()


                }
                saveButton.setOnClickListener {
                    val name = nameEditText.text.toString()
                    val mobile = mobileEditText.text.toString()
                    val password = passEditText.text.toString()

                    if (name.isNotEmpty() && mobile.isNotEmpty() && password.isNotEmpty()) {
                        // Show progress bar
                        progressBar.visibility = View.VISIBLE

                        // Create a map to update only the necessary fields
                        val updateData = mapOf<String, Any>(
                            "username" to name,
                            "mobile" to mobile,
                            "password" to password
                        )

                        // Update the specific button's data in the database
                        reference.updateChildren(updateData)
                            .addOnSuccessListener {
                                //Toast.makeText(this@EachUserPhone, "User data saved successfully!", Toast.LENGTH_SHORT).show()

                                addData(mobile,password,buttonName,name)
                                // Hide progress bar
                                progressBar.visibility = View.GONE
                                // Dismiss the dialog after saving
                                alertDialog.dismiss()
                            }
                            .addOnFailureListener { e ->
                               // Toast.makeText(this@EachUserPhone, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                                // Hide progress bar
                                progressBar.visibility = View.GONE
                            }
                    } else {
                        //Toast.makeText(this@EachUserPhone, "Please fill in all fields!", Toast.LENGTH_SHORT).show()
                    }
                }

            }

            override fun onCancelled(databaseError: DatabaseError) {
                progressBar.visibility = ProgressBar.GONE // Hide progress bar in case of error
               // Toast.makeText(this@EachUserPhone, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
            }
        })

        // Handle Edit button click to enable EditText fields for editing
        editButton.setOnClickListener {
            nameEditText.isEnabled = true
            mobileEditText.isEnabled = true
            passEditText.isEnabled = true
            nameEditText.requestFocus()
            saveButton.visibility = View.VISIBLE
            editButton.visibility = View.INVISIBLE
        }

        alertDialog = dialogBuilder.create() // Assign the created AlertDialog to alertDialog variable
        alertDialog.show()
    }

    private fun checkInData() {
        progress.visibility = ProgressBar.VISIBLE // Show progress bar

        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(mobilenum).child("Buildings")
            .child(buildingCode).child("blocks").child(blockButtonName)

        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (rowSnapshot in dataSnapshot.children) {
                    val buttonName = rowSnapshot.key
                    if (buttonName != null) {
                        val buttonData = rowSnapshot.value as? Map<String, Any>
                        val buttonColor = buttonData?.get("color") as? String
                        var col = ""

                        if (buttonColor.toString() == "rent") {
                            col = "#FFFF00"
                        } else  {
                            col = "#8BC34A"
                        }
                        // Find the button by its name and set the background color
                        val button = findButtonByName(buttonName)
                        if (button != null && buttonColor != null) {
                            button.setBackgroundColor(Color.parseColor(col))
                        }
                    }
                }
                progress.visibility = ProgressBar.GONE // Hide progress bar after processing data
            }

            override fun onCancelled(databaseError: DatabaseError) {
               // Toast.makeText(this@EachUserPhone, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
                progress.visibility = ProgressBar.GONE // Hide progress bar in case of error
            }
        })
    }

    private fun findButtonByName(buttonName: String): Button? {
        val container = findViewById<LinearLayout>(R.id.container)
        for (i in 0 until container.childCount) {
            val rowLayout = container.getChildAt(i) as? LinearLayout
            if (rowLayout != null) {
                for (j in 0 until rowLayout.childCount) {
                    val child = rowLayout.getChildAt(j)
                    if (child is Button && child.text.toString() == buttonName) {
                        return child
                    }
                }
            }
        }
        return null
    }

    private fun  addData(mob: String, password: String, buttonName: String, name: String){
        val database2 = FirebaseDatabase.getInstance()
        val reference2 = database2.getReference("Users")
            .child(mobilenum) // Replace with your specific user phone number
            .child("Buildings")
            .child(buildingCode) // Replace with your specific building code
            .child("UsersCredentials")
            .child(mob)

        val updateData = mapOf<String, Any>(
            "username" to name,
            "mobile" to mob,
            "password" to password
        )

        // Update the specific button's data in the database
        reference2.updateChildren(updateData)
            .addOnSuccessListener {
               // Toast.makeText(this@EachUserPhone, "User data saved successfully!", Toast.LENGTH_SHORT).show()

                addAuth(mob,password,buttonName,name)

                alertDialog.dismiss()
            }
            .addOnFailureListener { e ->
               // Toast.makeText(this@EachUserPhone, "Error: ${e.message}", Toast.LENGTH_SHORT).show()

            }

    }
    private fun  addAuth(mob: String, password: String, buttonName: String, name: String){
        val database2 = FirebaseDatabase.getInstance()
        val reference2 = database2.getReference("Users")
            .child("TotalCredentials")
             // Replace with your specific user phone number
            .child(mob)

        val updateData = mapOf<String, Any>(
            "username" to name,
            "mobile" to mob,
            "password" to password,
            "buildingcode" to buildingCode,
            "block" to blockButtonName,
            "apartment" to buttonName,
            "owner" to mobilenum
        )

        // Update the specific button's data in the database
        reference2.updateChildren(updateData)
            .addOnSuccessListener {
              //  Toast.makeText(this@EachUserPhone, "User data saved successfully!", Toast.LENGTH_SHORT).show()

                alertDialog.dismiss()
            }
            .addOnFailureListener { e ->
               // Toast.makeText(this@EachUserPhone, "Error: ${e.message}", Toast.LENGTH_SHORT).show()

            }

    }


}
