package com.example.dwell.User
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.dwell.MainActivity
import com.example.dwell.R

class UserProfile : AppCompatActivity() {

    private lateinit var profileNameTextView: TextView
    private lateinit var backButton: TextView
    private lateinit var usernameEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var blockNoEditText: EditText
    private lateinit var houseNoEditText: EditText
    private var owner: String = ""
    private var number: String = ""
    private lateinit var logout: TextView
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)

        profileNameTextView = findViewById(R.id.profilename)
        backButton = findViewById(R.id.back)
        usernameEditText = findViewById(R.id.username)
        phoneEditText = findViewById(R.id.phonetxt)
        blockNoEditText = findViewById(R.id.usermail)
        houseNoEditText = findViewById(R.id.usercardnumber)
        logout = findViewById(R.id.logout)

        // Retrieve data passed via intent
        val username = intent.getStringExtra("username")
        val storedPassword = intent.getStringExtra("storedPassword")
        val buildingCode = intent.getStringExtra("buildingCode")
        val block = intent.getStringExtra("block")
        val apartment = intent.getStringExtra("apartment")
        owner = intent.getStringExtra("owner").toString()
        number = intent.getStringExtra("number").toString()

        sharedPreferences = getSharedPreferences("MyPrefsmainlogin", Context.MODE_PRIVATE)

        // Set retrieved data to EditText fields
        usernameEditText.setText(username)
        phoneEditText.setText(number)
        blockNoEditText.setText(block)
        houseNoEditText.setText(apartment)

        backButton.setOnClickListener {
            finish()
        }

        logout.setOnClickListener {
            opendialog()
        }
    }

    private fun opendialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Logout")
        builder.setMessage("Are you sure you want to logout?")
        builder.setPositiveButton("Yes") { dialogInterface: DialogInterface, i: Int ->
            // User clicked Yes, perform logout action
            val editor = sharedPreferences.edit()
            editor.putString("status", "null")
            editor.apply()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
        builder.setNegativeButton("No") { dialogInterface: DialogInterface, i: Int ->
            // User clicked No, dismiss the dialog
            dialogInterface.dismiss()
        }
        builder.show()
    }
}
