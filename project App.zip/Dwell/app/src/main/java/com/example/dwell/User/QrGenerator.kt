package com.example.dwell.User
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.toBitmap
import com.example.dwell.R
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.WriterException
import com.journeyapps.barcodescanner.BarcodeEncoder
import kotlin.random.Random

class QrGenerator : AppCompatActivity() {

    private lateinit var qrCodeImageView: ImageView
    private lateinit var qrUniqueCode: TextView
    private lateinit var share: Button
    private lateinit var uniqCode:String
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr_generator)

        uniqCode=intent.getStringExtra("uniq").toString()

        qrCodeImageView = findViewById(R.id.qrCodeImageView)
        qrUniqueCode = findViewById(R.id.QrTextView)
        share = findViewById(R.id.share)


        qrUniqueCode.text=uniqCode
        generateQRCode()

        share.setOnClickListener {
            shareCodeQr()
        }
    }

    private fun generateQRCode() {
        try {
            // Generate QR code
            val multiFormatWriter = MultiFormatWriter()
            val bitMatrix = multiFormatWriter.encode(uniqCode, BarcodeFormat.QR_CODE, 500, 500)
            val barcodeEncoder = BarcodeEncoder()
            val bitmap: Bitmap = barcodeEncoder.createBitmap(bitMatrix)
            qrCodeImageView.setImageBitmap(bitmap)
        } catch (e: WriterException) {
            e.printStackTrace()
        }
    }

    private fun shareCodeQr() {
        val uri: Uri = getImageUri(this, qrCodeImageView)

        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "image/*"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.putExtra(Intent.EXTRA_TEXT, uniqCode)

        startActivity(Intent.createChooser(intent, "Share QR Code via"))
    }




    private fun getImageUri(inContext: AppCompatActivity, inImage: ImageView): Uri {
        val bitmap = (inImage.drawable).toBitmap()
        val path = MediaStore.Images.Media.insertImage(inContext.contentResolver, bitmap, "QRCode", null)
        return Uri.parse(path)
    }
}
