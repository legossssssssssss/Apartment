package com.example.dwell.Admin

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.dwell.R
import com.google.firebase.database.*

class EachSectionInBlock : AppCompatActivity() {
    private lateinit var mobilenum: String
    private lateinit var buildingCode: String
    private lateinit var maxUnits: String
    private lateinit var totalFloors: String
    private lateinit var save: Button
    private lateinit var container: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var blockButtonName: String
    private lateinit var selected: String
    private val colors = listOf("#FFFF00", "#8BC34A") // Red, Yellow, Green
    private var currentColorIndex = 0
    private lateinit var totalBlocks: String

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_each_section_in_block)

        mobilenum = intent.getStringExtra("mobile").toString()
        buildingCode = intent.getStringExtra("code").toString()
        maxUnits = intent.getStringExtra("maxunits").toString()
        totalFloors = intent.getStringExtra("totalfloors").toString()
        blockButtonName = intent.getStringExtra("blockbutton").toString()
        selected = intent.getStringExtra("selected").toString()
        totalBlocks = intent.getStringExtra("total").toString()

        progress = findViewById(R.id.progressBar)
        container = findViewById(R.id.container)

        save = findViewById(R.id.save)

        save.setOnClickListener {
            saveButtonToData()
        }

        val number = totalFloors.toIntOrNull() ?: 0
        val number2 = maxUnits.toIntOrNull() ?: 0
        generateButtons(number, number2, container)

        // Check if data exists in Firebase and apply colors to buttons accordingly
        checkInData()
    }

    private fun saveButtonToData() {
        progress.visibility = ProgressBar.VISIBLE

        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(mobilenum).child("Buildings")
            .child(buildingCode).child("blocks").child(blockButtonName)

        for (i in 1..container.childCount) {
            val rowLayout = container.getChildAt(i - 1) as LinearLayout
            for (j in 0 until rowLayout.childCount) {
                val button = rowLayout.getChildAt(j) as Button
                val buttonName = button.text.toString()
                val buttonColor = getButtonColor(button)

                val buttonData = hashMapOf(
                    "color" to buttonColor,
                    "name" to buttonName
                )
                reference.child(buttonName).setValue(buttonData)
                    .addOnSuccessListener {
                        progress.visibility = ProgressBar.GONE

                        val intent = Intent(this, BlockViews::class.java)
                        intent.putExtra("status", blockButtonName)
                        intent.putExtra("totalblocks", totalBlocks)
                        intent.putExtra("code", buildingCode)
                        intent.putExtra("mobile", mobilenum)
                        startActivity(intent)
                        finish()
                    }
                    .addOnFailureListener { e ->
                        showErrorDialog(e.message)
                        progress.visibility = ProgressBar.GONE
                    }
            }
        }
    }

    private fun showErrorDialog(message: String?) {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setMessage(message)
            .setCancelable(false)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }

        val alert = dialogBuilder.create()
        alert.setTitle("Error")
        alert.show()
    }

    private fun generateButtons(number: Int, number2: Int, container: LinearLayout) {
        for (i in number downTo 1) {
            val rowLayout = LinearLayout(this)
            rowLayout.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rowLayout.orientation = LinearLayout.HORIZONTAL

            for (j in 0 until number2) {
                val button = Button(this)
                button.layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )

                if (i == 1) {
                    button.text = "G${j + 1}"
                } else {
                    button.text = "${i - 1}0${j + 1}" // Button label
                }

                button.setBackgroundColor(Color.parseColor("#00000000")) // Initial color transparent

                button.setOnClickListener {
                    currentColorIndex = (currentColorIndex + 1) % colors.size
                    button.setBackgroundColor(Color.parseColor(colors[currentColorIndex]))
                }

                rowLayout.addView(button)
            }

            container.addView(rowLayout)
        }
    }

    private fun getButtonColor(button: Button): String {
        val colorDrawable = button.background as? ColorDrawable
        val colorCode = colorDrawable?.color ?: Color.TRANSPARENT
        val hexColor = String.format("#%06X", 0xFFFFFF and colorCode)

        return when (hexColor) {
            "#FFFF00" -> "rent" // Yellow
            "#8BC34A" -> "owner" // Green
            else -> "#000000" // Default if not found in the list
        }
    }

    private fun checkInData() {
        progress.visibility = ProgressBar.VISIBLE // Show progress bar

        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(mobilenum).child("Buildings")
            .child(buildingCode).child("blocks").child(blockButtonName)

        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (rowSnapshot in dataSnapshot.children) {
                    val buttonName = rowSnapshot.key
                    if (buttonName != null) {
                        val buttonData = rowSnapshot.value as? Map<String, Any>
                        val buttonColor = buttonData?.get("color") as? String
                        var col = ""

                        if (buttonColor.toString() == "rent") {
                            col = "#FFFF00"
                        } else if (buttonColor.toString() == "owner") {
                            col = "#8BC34A"
                        } else {
                            col = "#FF0000"
                        }

                        // Find the button by its name and set the background color
                        val button = findButtonByName(buttonName)
                        if (button != null && buttonColor != null) {
                            button.setBackgroundColor(Color.parseColor(col))
                        }
                    }
                }
                progress.visibility = ProgressBar.GONE // Hide progress bar after processing data
            }

            override fun onCancelled(databaseError: DatabaseError) {
                //Toast.makeText(this@EachSectionInBlock, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
                progress.visibility = ProgressBar.GONE // Hide progress bar in case of error
            }
        })
    }

    private fun findButtonByName(buttonName: String): Button? {
        val container = findViewById<LinearLayout>(R.id.container)
        for (i in 0 until container.childCount) {
            val rowLayout = container.getChildAt(i) as? LinearLayout
            if (rowLayout != null) {
                for (j in 0 until rowLayout.childCount) {
                    val child = rowLayout.getChildAt(j)
                    if (child is Button && child.text.toString() == buttonName) {
                        return child
                    }
                }
            }
        }
        return null
    }
}
