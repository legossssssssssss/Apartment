package com.example.dwell.User


data class InteractionData(
    val heading: String = "",
    val subject:String="",
    val description: String = "",
    val date: String = ""

)