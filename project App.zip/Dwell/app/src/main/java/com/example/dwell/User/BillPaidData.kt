package com.example.dwell.User
data class BillPaidData(
    val key: String="",
    val title: String = "",
    val description: String = "",
    val deadline: String = "",
    val block: String = "",
    val price: String = "",
    val currentDate: String="",
    val status:String="",
    val buildingcode:String="",
    val owner:String=""

)
