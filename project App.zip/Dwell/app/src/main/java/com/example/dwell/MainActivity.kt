package com.example.dwell

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import com.example.dwell.Admin.AddBuilding
import com.example.dwell.Admin.GateKeeper
import com.example.dwell.User.UserMainView
import com.example.dwell.User.UserProfile
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    private lateinit var mobileNumberEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var signUpTextView: TextView
    private lateinit var mAuth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference
    private lateinit var sharedPreferences: SharedPreferences

    private lateinit var username: String
    private lateinit var storedPassword: String
    private lateinit var buildingCode: String
    private lateinit var block: String
    private lateinit var apartment: String
    private lateinit var owner: String
    private lateinit var number: String
    private lateinit var progress:ProgressBar

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mobileNumberEditText = findViewById(R.id.mobilenumber_loginactivity)
        passwordEditText = findViewById(R.id.secretpassword_loginactivity)
        loginButton = findViewById(R.id.signinbutton_loginactivity)
        signUpTextView = findViewById(R.id.RegisternowTextview_loginactivity)
        progress=findViewById(R.id.progressBar)

        mAuth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child("Authentication")
        sharedPreferences = getSharedPreferences("MyPrefsmainlogin", Context.MODE_PRIVATE)

        signUpTextView.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }

        loginButton.setOnClickListener {
            val mobile = mobileNumberEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (mobile.isNotEmpty() && password.isNotEmpty()) {
                checkLoginData(mobile, password)
            } else {
               // Toast.makeText(this, "Enter Valid Credentials", Toast.LENGTH_SHORT).show()
            }
        }

        handleLoginNavigation()
    }

    private fun handleLoginNavigation() {
        val phNum = sharedPreferences.getString("phoneNumber", null)
        val status = sharedPreferences.getString("status", null)
        if (!phNum.isNullOrEmpty() && status.toString() == "owner") {
            navigateToAddBuilding(phNum)
        }
        if (!phNum.isNullOrEmpty() && status.toString() == "user"){
            // Retrieve user details from SharedPreferences if available
            username = sharedPreferences.getString("username", "") ?: ""
            storedPassword = sharedPreferences.getString("storedPassword", "") ?: ""
            buildingCode = sharedPreferences.getString("buildingCode", "") ?: ""
            block = sharedPreferences.getString("block", "") ?: ""
            apartment = sharedPreferences.getString("apartment", "") ?: ""
            owner = sharedPreferences.getString("owner", "") ?: ""
            number = sharedPreferences.getString("number", "") ?: ""
            navigateToUser(username, storedPassword, buildingCode, block, apartment, owner, number)
        }
        if (!phNum.isNullOrEmpty() && status.toString()=="security"){
            storedPassword = sharedPreferences.getString("storedPassword", "") ?: ""
            buildingCode = sharedPreferences.getString("buildingCode", "") ?: ""
            owner = sharedPreferences.getString("owner", "") ?: ""
            number = sharedPreferences.getString("number", "") ?: ""
            navigateToGate(number,owner,storedPassword,buildingCode)

        }
    }

    private fun checkLoginData(mobile: String, password: String) {
        progress.visibility=View.VISIBLE
        databaseReference.child(mobile).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val passwordFromDatabase = snapshot.value as? String
                if (passwordFromDatabase == password) {
                    val editor = sharedPreferences.edit()
                    editor.putString("phoneNumber", mobile)
                    editor.putString("status", "owner")
                    // Save user details to SharedPreferences

                    editor.apply()
                    progress.visibility=View.INVISIBLE
                    //Toast.makeText(this@MainActivity, "Login Successful", Toast.LENGTH_SHORT).show()

                    navigateToAddBuilding(mobile)
                } else {
                    checkInTotal(mobile, password)
                    //Toast.makeText(this@MainActivity, "Incorrect Mobile number or Password", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                progress.visibility=View.INVISIBLE
                //Toast.makeText(this@MainActivity, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun checkInTotal(mobile: String, password: String) {
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users")
            .child("TotalCredentials")
            .child(mobile)

        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    number = snapshot.key.toString()
                    // Data exists for the given mobile number
                    username = snapshot.child("username").getValue(String::class.java).toString()
                    storedPassword = snapshot.child("password").getValue(String::class.java).toString()
                    buildingCode = snapshot.child("buildingcode").getValue(String::class.java).toString()
                    block = snapshot.child("block").getValue(String::class.java).toString()
                    apartment = snapshot.child("apartment").getValue(String::class.java).toString()
                    owner = snapshot.child("owner").getValue(String::class.java).toString()

                    // Now you have retrieved the data, you can use it as needed.
                    // For example, you might compare the stored password with the provided password.
                    if (password == storedPassword) {
                        // Password is correct, proceed with login
                        progress.visibility=View.INVISIBLE
                        val editor = sharedPreferences.edit()
                        editor.putString("phoneNumber",number)
                        editor.putString("status", "user")
                        editor.putString("username", username)
                        editor.putString("storedPassword", storedPassword)
                        editor.putString("buildingCode", buildingCode)
                        editor.putString("block", block)
                        editor.putString("apartment", apartment)
                        editor.putString("owner", owner)
                        editor.putString("number",number)
                        editor.apply()

                        navigateToUser(username, storedPassword, buildingCode, block, apartment, owner, number)
                    } else {
                        // Incorrect password
                        progress.visibility=View.INVISIBLE
                       // Toast.makeText(this@MainActivity, "Incorrect Password ", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    // No data found for the given mobile number
                    //Toast.makeText(this@MainActivity, "Mobile number not found Enter Valid Credentials", Toast.LENGTH_SHORT).show()
                    checkInSecurityData(mobile,password)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                progress.visibility=View.INVISIBLE
               // Toast.makeText(this@MainActivity, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun checkInSecurityData(mobile: String, password: String) {
        val database3 = FirebaseDatabase.getInstance()
        val reference3 = database3.getReference("Users")
            .child("TotalGateKeeperCredentials")
            .child(mobile)

        reference3.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    number = snapshot.key.toString()
                    storedPassword = snapshot.child("password").getValue(String::class.java).toString()
                    buildingCode = snapshot.child("buildingcode").getValue(String::class.java).toString()
                    owner = snapshot.child("owner").getValue(String::class.java).toString()

                    // Now you have retrieved the data, you can use it as needed.
                    // For example, you might compare the stored password with the provided password.
                    if (password == storedPassword) {
                        // Password is correct, proceed with login
                        //Toast.makeText(this@MainActivity, "Login Successful", Toast.LENGTH_SHORT).show()
                        val editor = sharedPreferences.edit()
                        editor.putString("phoneNumber",number)
                        editor.putString("status", "security")
                        editor.putString("storedPassword", storedPassword)
                        editor.putString("buildingCode", buildingCode)
                        editor.putString("owner", owner)
                        editor.putString("number",number)
                        editor.apply()
                        progress.visibility=View.INVISIBLE
                        navigateToGate(number,owner,storedPassword,buildingCode)
                    } else {
                        // Incorrect password
                        progress.visibility=View.INVISIBLE
                       // Toast.makeText(this@MainActivity, "Incorrect Password In security", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    // No data found for the given mobile number
                    //Toast.makeText(this@MainActivity, "Mobile number not found Enter Valid Credentials", Toast.LENGTH_SHORT).show()
                    progress.visibility=View.INVISIBLE
                }
            }

            override fun onCancelled(error: DatabaseError) {
                progress.visibility=View.INVISIBLE
               // Toast.makeText(this@MainActivity, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })



    }



    private fun navigateToUser(username: String?, storedPassword: String, buildingCode: String?, block: String?, apartment: String?, owner: String?, number: String?
    ) {


        val intent = Intent(this, UserMainView::class.java).apply {
            putExtra("username", username)
            putExtra("storedPassword", storedPassword)
            putExtra("buildingCode", buildingCode)
            putExtra("block", block)
            putExtra("apartment", apartment)
            putExtra("owner", owner)
            putExtra("phone",number)
        }
        startActivity(intent)
        finish()
    }

    private fun navigateToAddBuilding(phoneNumber: String) {
        val intent = Intent(this, AddBuilding::class.java)
        intent.putExtra("phoneNumber", phoneNumber)
        startActivity(intent)
        finish()
    }
    private fun navigateToGate(number: String?,owner: String?,storedPassword: String,buildingCode: String?){
        val intent = Intent(this, GateKeeper::class.java).apply {
            putExtra("storedPassword", storedPassword)
            putExtra("buildingCode", buildingCode)
            putExtra("owner", owner)
            putExtra("phone",number)
        }
        startActivity(intent)
        finish()

    }


}
