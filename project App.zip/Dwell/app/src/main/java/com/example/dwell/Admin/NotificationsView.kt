package com.example.dwell.Admin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.dwell.R

class NotificationsView : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications_view)
    }
}