package com.example.dwell.User

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class UserBilss : AppCompatActivity() {

    private lateinit var back: TextView
    private lateinit var recyclerview: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var billAdapter: UserBillAdapter
    private lateinit var owner:String
    private lateinit var buildingcode:String
    private lateinit var block:String
    private lateinit var apart:String
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_bilss)

        owner=intent.getStringExtra("phoneNumber").toString()
        //Toast.makeText(this,owner,Toast.LENGTH_SHORT).show()
        buildingcode=intent.getStringExtra("code").toString()
       // Toast.makeText(this,buildingcode,Toast.LENGTH_SHORT).show()
        block=intent.getStringExtra("block").toString()
        //Toast.makeText(this,block,Toast.LENGTH_SHORT).show()
        apart=intent.getStringExtra("apart").toString()
        //Toast.makeText(this,apart,Toast.LENGTH_SHORT).show()

        back = findViewById(R.id.back)
        recyclerview = findViewById(R.id.recyler)
        progress = findViewById(R.id.progressBar)

        fetchdata()

        // Initialize billAdapter
        billAdapter = UserBillAdapter(ArrayList(),apart)

        // Set billAdapter to RecyclerView
        recyclerview.adapter = billAdapter

        back.setOnClickListener {
            finish()
        }


    }
    private fun fetchdata() {
        progress.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val billsReference = database.getReference("Users")
            .child(owner) // Replace with your specific user phone number
            .child("Buildings")
            .child(buildingcode) // Replace with your specific building code
            .child("blocks")
            .child(block)
            .child(apart)
            .child("bills")
        billsReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val billsList = ArrayList<BillPaidData>()
                for (billSnapshot in snapshot.children) {
                    val key = billSnapshot.key // Get the bill key
                    val bill = billSnapshot.getValue(BillPaidData::class.java)
                    bill?.let {
                        // Add the key to the BillData object
                        val billWithKey = it.copy(key = key ?: "") // If key is null, assign an empty string
                        billsList.add(billWithKey)
                    }
                }

                recyclerview.layoutManager = LinearLayoutManager(this@UserBilss) // Change this line
                billAdapter.add(billsList) // Change this line
                progress.visibility = View.INVISIBLE

            }

            override fun onCancelled(error: DatabaseError) {
              //  Toast.makeText(this@UserBilss, "Failed to retrieve data: ${error.message}", Toast.LENGTH_SHORT).show()
                progress.visibility = View.GONE
            }
        })
    }


}