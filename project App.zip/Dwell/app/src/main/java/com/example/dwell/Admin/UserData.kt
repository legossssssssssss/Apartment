package com.example.dwell.Admin

data class UserData(val username: String = "", val mobile: String = "", val password: String = "")
