package com.example.dwell.User

class GatePassData (
    val Name: String="",
    val PhoneNumber: String="",
    val Address: String="",
    val FromDate: String="",
    val ToDate: String="",
    val Block: String="",
    val Flat: String="",
    val OwnerName: String="",
    val uniqcode:String=""

)