package com.example.dwell.User
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dwell.R
import com.google.firebase.database.*

class UserNotifications : AppCompatActivity() {
    private lateinit var back: TextView
    private lateinit var recyclerview: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var cmpAdapter: NotificationAdapter
    private lateinit var notificationsharedpreferences:SharedPreferences
    private lateinit var mobile:String
    private lateinit var Buildingcode:String
    private lateinit var block:String
    private lateinit var notcheck:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_notifications)

        mobile=intent.getStringExtra("phoneNumber").toString()
        Buildingcode=intent.getStringExtra("code").toString()
        block=intent.getStringExtra("block").toString()
        notcheck=intent.getStringExtra("notcheck").toString()

        notificationsharedpreferences = getSharedPreferences("notifications", Context.MODE_PRIVATE)

        back = findViewById(R.id.back)
        recyclerview = findViewById(R.id.recycler)
        progress = findViewById(R.id.progressBar)




        val editor = notificationsharedpreferences.edit()
        editor.putString("check",notcheck)
        editor.apply()

        // Set up RecyclerView
        recyclerview.layoutManager = LinearLayoutManager(this)
        cmpAdapter = NotificationAdapter(ArrayList())
        recyclerview.adapter = cmpAdapter

        back.setOnClickListener {
            val intent=Intent(this,UserMainView::class.java)
            startActivity(intent)
            finish()
        }

        fetchData()
    }

    private fun fetchData() {
        progress.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val notificationsReference = database.getReference("Users")
            .child(mobile)
            .child("Buildings")
            .child(Buildingcode)
            .child("Notifications")
            .child("Users")

        notificationsReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val notificationList = ArrayList<NotificationModel>()
                for (notificationSnapshot in snapshot.children) {
                    if (notificationSnapshot.key != "blink") {
                        try {
                            val notification = notificationSnapshot.getValue(NotificationModel::class.java)
                            notification?.let {
                                notificationList.add(it)
                            }
                        } catch (e: DatabaseException) {
                            e.printStackTrace()
                            // Handle the exception or log it
                            // This will catch any conversion errors
                        }
                    }
                }
                cmpAdapter.notificationList = notificationList
                cmpAdapter.notifyDataSetChanged()
                progress.visibility = View.GONE
            }

            override fun onCancelled(error: DatabaseError) {
                progress.visibility = View.GONE
               // Toast.makeText(this@UserNotifications, "Failed to fetch data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun NotifyBlink(){
        val databaseReference = FirebaseDatabase.getInstance().reference
        val interactionRef = databaseReference
            .child("Users")
            .child(mobile)
            .child("Buildings")
            .child(Buildingcode)
            .child("Notifications")
            .child("Users")
            .child("blink").setValue("true")

        progress.visibility = ProgressBar.VISIBLE


        interactionRef
            .addOnSuccessListener {
                progress.visibility = ProgressBar.GONE
                //Toast.makeText(this, "Notification Blinked Succesfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                progress.visibility = ProgressBar.GONE
                //Toast.makeText(this, "Failed  to Blink  Notification   ", Toast.LENGTH_SHORT).show()
            }

    }

}
