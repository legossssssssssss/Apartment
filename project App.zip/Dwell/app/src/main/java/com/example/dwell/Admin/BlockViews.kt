package com.example.dwell.Admin

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import com.example.dwell.R
import com.google.firebase.database.*

class BlockViews : AppCompatActivity() {

    private lateinit var mobilenum: String
    private lateinit var buildingcode: String
    private lateinit var totalblocks: String
    private lateinit var progress: ProgressBar
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var buildingname:String
    private lateinit var editing:String
    private lateinit var next:Button

    private val buttonNamesList = mutableListOf<String>()

    private lateinit var database: FirebaseDatabase
    private lateinit var reference: DatabaseReference
    private var blocks:Int=0

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_block_views)

        progress = findViewById(R.id.progressBar)
        next=findViewById(R.id.nextbutt)

        sharedPreferences = getSharedPreferences("MyPrefsviewsb", Context.MODE_PRIVATE)
        val phnum = sharedPreferences.getString("phoneNumber", "").toString()
        val bc = sharedPreferences.getString("BuildingCode", "").toString()
        val tb = sharedPreferences.getString("TotalBlocks", "").toString()
        val bdname = sharedPreferences.getString("buildname", "").toString()
        val sta = sharedPreferences.getString("status", "").toString()
        editing=intent.getStringExtra("edit").toString()
        val container = findViewById<LinearLayout>(R.id.container)
        if (editing=="edit"){
            totalblocks = intent.getStringExtra("totalblocks").toString()
            mobilenum = intent.getStringExtra("mobile").toString()
            buildingcode = intent.getStringExtra("code").toString()
            buildingname = intent.getStringExtra("buildname").toString()
            generateButtons(totalblocks.toInt(),container)
            if (tb.isNotEmpty()){
                lightUpButtons(tb.toInt())

            }

            next.visibility=View.VISIBLE


            database = FirebaseDatabase.getInstance()
            reference = database.getReference("Users").child(mobilenum).child("Buildings")
                .child(buildingcode).child("blocks")




               // checkForBlockInFirebase()


        }


        else if (phnum.isNotEmpty() && bc.isNotEmpty() && tb.isNotEmpty() && bdname.isNotEmpty() && sta == "filled") {
            val intent = Intent(
                this,
                AdminMainView::class.java
            ) // Replace YourActivity with your desired activity
            intent.putExtra("phoneNumber", phnum)
            intent.putExtra("code", bc)
            intent.putExtra("total", tb)
            intent.putExtra("buildname", bdname)
            startActivity(intent)
            finish()
        } else {
            totalblocks = intent.getStringExtra("totalblocks").toString()
            mobilenum = intent.getStringExtra("mobile").toString()
            buildingcode = intent.getStringExtra("code").toString()
            buildingname = intent.getStringExtra("buildname").toString()

            if (totalblocks.isNotEmpty() && mobilenum.isNotEmpty() && buildingcode.isNotEmpty() && buildingname.isNotEmpty()) {
                val editor = sharedPreferences.edit()
                editor.putString("phoneNumber", mobilenum)
                editor.putString("BuildingCode", buildingcode)
                editor.putString("TotalBlocks", totalblocks)
                editor.putString("buildname", buildingname)
                editor.apply()

                database = FirebaseDatabase.getInstance()
                reference = database.getReference("Users").child(mobilenum).child("Buildings")
                    .child(buildingcode).child("blocks")

                val container = findViewById<LinearLayout>(R.id.container)
                generateButtons(totalblocks.toInt(), container)

                checkForBlockInFirebase()

            }



        }
        next.setOnClickListener {
            val editor = sharedPreferences.edit()
            editor.putString("phoneNumber", mobilenum)
            editor.putString("BuildingCode", buildingcode)
            editor.putString("TotalBlocks", totalblocks)
            editor.putString("buildname", buildingname)
            editor.putString("status","filled")
            editor.apply()
            navigate()
        }
    }

    private fun generateButtons(number: Int, container: LinearLayout) {
        val buttonNames = ('A'..'Z').take(number) // Generate button names from A to Z
        for (name in buttonNames) {
            buttonNamesList.add("Block$name")
            val button = Button(this)
            button.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            val buttonText = "Block$name"
            button.text = buttonText // Set button text as BlockA, BlockB, etc.
            button.background.setTint(resources.getColor(R.color.pastel_red)) // Set initial color to pastel red

            // Set click listeners for the buttons
            button.setOnClickListener {
                val intent = Intent(this, BlockDetails::class.java)
                intent.putExtra("buttonText", buttonText)
                intent.putExtra("mobile", mobilenum)
                intent.putExtra("code", buildingcode)
                intent.putExtra("total",totalblocks)
                intent.putExtra("buildname",buildingname)

                startActivity(intent)
            }

            container.addView(button) // Add button to the container
        }
    }

    private fun checkForBlockInFirebase() {
        progress.visibility = View.VISIBLE
        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                var blockFoundCount = 0 // Variable to count the number of blocks found in Firebase
                for (buttonSnapshot in dataSnapshot.children) {
                    val buttonName = buttonSnapshot.key
                    if (buttonName != null) {
                        val button = findButtonByName(buttonName)
                        if (button != null) {
                            // Set button color to green if block exists in Firebase
                            button.background.setTint(resources.getColor(R.color.pastel_green))
                            blockFoundCount++
                        }
                    }
                }
                if (blockFoundCount == totalblocks.toInt()) { // Check if all blocks are found
                    val editor = sharedPreferences.edit()
                    editor.putString("status","filled")
                    editor.apply()

                    // Show congratulations message and navigate
                  //  Toast.makeText(this@BlockViews, "Congratulations! You have set your building key. Let the magic begin!", Toast.LENGTH_SHORT).show()
                    navigate()
                } else {
                    // Not all blocks found, hide progress bar
                    progress.visibility = View.INVISIBLE
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle database error
               // Toast.makeText(this@BlockViews, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
                // Set button color to red on error
                val container = findViewById<LinearLayout>(R.id.container)
                for (i in 0 until container.childCount) {
                    val child = container.getChildAt(i)
                    if (child is Button) {
                        child.background.setTint(resources.getColor(R.color.pastel_red))
                    }
                }
                progress.visibility = View.INVISIBLE
            }
        })
    }

    private fun findButtonByName(buttonName: String): Button? {
        val container = findViewById<LinearLayout>(R.id.container)
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i)
            if (child is Button && child.text.toString() == buttonName) {
                return child
            }
        }
        return null
    }

    private fun navigate() {

        // Navigate to the next activity
        val intent = Intent(this, AdminMainView::class.java)
        startActivity(intent)
        finish()
    }

    private fun checkIfAllBlocksFilled() {
        val container = findViewById<LinearLayout>(R.id.container)
        var allBlocksFilled = true
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i)
            if (child is Button) {
                val colorDrawable = child.background as? ColorDrawable
                val color = colorDrawable?.color ?: Color.TRANSPARENT
                if (color == resources.getColor(R.color.pastel_red)) {
                    allBlocksFilled = false
                    break
                }
            }
        }
        if (allBlocksFilled) {
            navigate()
        } else {
           // Toast.makeText(this@BlockViews, "Please fill all blocks before proceeding.", Toast.LENGTH_SHORT).show()
        }
    }
    private fun checkBlocks() {
        database = FirebaseDatabase.getInstance()
        reference = database.getReference("Users").child(mobilenum).child("Buildings")
            .child(buildingcode).child("blocks")
        progress.visibility = View.VISIBLE
        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (buttonSnapshot in dataSnapshot.children) {
                    val blockName = buttonSnapshot.key
                    if (blockName != null) {
                        val button = findButtonByName(blockName)
                        if (button != null) {
                            // Set button color to green if block exists in Firebase
                            button.background.setTint(resources.getColor(R.color.pastel_green))
                        }
                    }
                }
                progress.visibility = View.INVISIBLE
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle database error
               // Toast.makeText(this@BlockViews, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
                progress.visibility = View.INVISIBLE
            }
        })
    }
    private fun lightUpButtons(count: Int) {
        val container = findViewById<LinearLayout>(R.id.container)
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i)
            if (child is Button) {
                if (i < count) {
                    // Set button color to green to light up
                    child.background.setTint(resources.getColor(R.color.pastel_green))
                } else {
                    // Set button color to default color to turn off
                    child.background.setTint(resources.getColor(R.color.pastel_red))
                }
            }
        }
    }


}
