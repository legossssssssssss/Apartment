package com.example.dwell.User

data class BillData(
    val key: String="",
    val title: String = "",
    val description: String = "",
    val deadline: String = "",
    val block: String = "",
    val price: String = "",
    val currentDate: String="",
    val status: String="",
    val owner: String="",
    val buildingcode: String=""
)