package com.example.dwell.Admin
import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.view.View
import android.widget.TextView
import com.example.dwell.AdminprofileClass
import com.example.dwell.MainActivity
import com.example.dwell.R
import com.google.firebase.database.*

class AdminProfile : AppCompatActivity() {
    private lateinit var save: Button
    private lateinit var edit:Button
    private lateinit var mobile: String
    private lateinit var BuildingCode: String
    private lateinit var mobilenumber: EditText
    private lateinit var editTextName: EditText
    private lateinit var editTextState: EditText
    private lateinit var editTextPincode: EditText
    private lateinit var editTextCity: EditText
    private lateinit var editTextAddress: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var databaseReference: DatabaseReference
    private lateinit var add: TextView
    private lateinit var back:TextView
    private lateinit var logout:TextView
    private lateinit var sharedPreferences: SharedPreferences

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_profile)

        save = findViewById(R.id.buttonsave)
        edit=findViewById(R.id.buttonedit)
        mobilenumber = findViewById(R.id.editTextMobile)
        editTextName = findViewById(R.id.editTextName)
        editTextState = findViewById(R.id.editTextState)
        editTextPincode = findViewById(R.id.editTextPincode)
        editTextCity = findViewById(R.id.editTextCity)
        editTextAddress = findViewById(R.id.editTextAddress)
        progressBar = findViewById(R.id.progressBar)
        add=findViewById(R.id.add)
        back=findViewById(R.id.back)
        logout=findViewById(R.id.logout)

        mobile=intent.getStringExtra("mobile").toString()
        BuildingCode=intent.getStringExtra("code").toString()
        sharedPreferences = getSharedPreferences("MyPrefsmainlogin", Context.MODE_PRIVATE)

        mobilenumber.setText(mobile)

        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(mobile).child("adminprofile")

        fetchData()

        sharedPreferences = getSharedPreferences("MyPrefsmainlogin", Context.MODE_PRIVATE)

        back.setOnClickListener {
            finish()
        }

        edit.setOnClickListener {
            enableEditTexts()
            save.visibility=View.VISIBLE
            edit.visibility=View.INVISIBLE
            editTextName.requestFocus()

        }
        add.setOnClickListener {
            val intent=Intent(this,AddBuilding::class.java)
            intent.putExtra("edit","edit")
            startActivity(intent)
            finish()
        }
        logout.setOnClickListener {
            opendialog()

        }
        save.setOnClickListener {

            if (checkFieldsNotEmpty()) {
                progressBar.visibility = ProgressBar.VISIBLE
                addDataToFirebase()
            } else {
              //  Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun checkFieldsNotEmpty(): Boolean {
        return editTextName.text.isNotEmpty() &&
                editTextState.text.isNotEmpty() &&
                editTextPincode.text.isNotEmpty() &&
                editTextCity.text.isNotEmpty() &&
                editTextAddress.text.isNotEmpty()
    }

    private fun addDataToFirebase() {
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("Users").child(mobile)

        val adminProfile = hashMapOf(
            "name" to editTextName.text.toString(),
            "state" to editTextState.text.toString(),
            "pincode" to editTextPincode.text.toString(),
            "city" to editTextCity.text.toString(),
            "address" to editTextAddress.text.toString(),
            "phone" to mobile
        )

        reference.child("adminprofile").setValue(adminProfile)
            .addOnSuccessListener {
                progressBar.visibility = ProgressBar.INVISIBLE
                save.visibility=View.INVISIBLE
                edit.visibility=View.VISIBLE
                disableEditTexts()
                val intent=Intent(this,AdminMainView::class.java)
                startActivity(intent)
                finish()
            }
            .addOnFailureListener {
                progressBar.visibility = ProgressBar.GONE
                showErrorDialog(it.message ?: "Unknown error occurred")
            }
    }

    private fun fetchData() {
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    val adminProfile = dataSnapshot.getValue(AdminprofileClass::class.java)
                    adminProfile?.let {
                        editTextName.setText(it.name)
                        editTextState.setText(it.state)
                        editTextPincode.setText(it.pincode)
                        editTextCity.setText(it.city)
                        editTextAddress.setText(it.address)
                    }
                    // Disable all EditTexts
                    disableEditTexts()
                    progressBar.visibility=View.INVISIBLE
                } else {
                    // Show dialog if no data is available
                    progressBar.visibility=View.INVISIBLE
                    showNoDataDialog()

                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Show error dialog
                showErrorDialog(databaseError.message)
            }
        })
    }

    private fun disableEditTexts() {
        editTextName.isEnabled = false
        editTextState.isEnabled = false
        editTextPincode.isEnabled = false
        editTextCity.isEnabled = false
        editTextAddress.isEnabled = false
    }
    private fun enableEditTexts() {
        editTextName.isEnabled = true
        editTextState.isEnabled = true
        editTextPincode.isEnabled = true
        editTextCity.isEnabled = true
        editTextAddress.isEnabled = true
    }


    private fun showErrorDialog(errorMessage: String?) {
        AlertDialog.Builder(this@AdminProfile)
            .setMessage(errorMessage ?: "Unknown error occurred")
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .create()
            .show()
    }

    private fun showNoDataDialog() {
        AlertDialog.Builder(this@AdminProfile)
            .setMessage("No data available")
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .create()
            .show()
    }
    private fun opendialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Logout")
        builder.setMessage("Are you sure you want to logout?")
        builder.setPositiveButton("Yes") { dialogInterface: DialogInterface, i: Int ->
            // User clicked Yes, perform logout action
            val editor = sharedPreferences.edit()
            editor.putString("status", "null")
            editor.apply()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
        builder.setNegativeButton("No") { dialogInterface: DialogInterface, i: Int ->
            // User clicked No, dismiss the dialog
            dialogInterface.dismiss()
        }
        builder.show()
    }
}
