package com.example.dwell.Admin

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.dwell.R
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase

class MyBuilding : AppCompatActivity() {

    private lateinit var database: FirebaseDatabase
    private lateinit var reference: DatabaseReference
    private lateinit var progress: ProgressBar
    private lateinit var mymobile:String
    private lateinit var buildingcode:String
    private lateinit var totalblocks:String



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_building)

        mymobile=intent.getStringExtra("mobile").toString()
        buildingcode=intent.getStringExtra("code").toString()
        totalblocks=intent.getStringExtra("totalblocks").toString()

        progress = findViewById(R.id.progressBar)

        database = FirebaseDatabase.getInstance()
        reference = database.getReference("Users").child(mymobile).child("Buildings").child(buildingcode).child("blocks")
        val container = findViewById<LinearLayout>(R.id.container)
        generateButtons(totalblocks.toInt(),container)
        lightUpButtons(totalblocks.toInt())
    }

    private fun fetchBlocks() {
        progress.visibility = ProgressBar.VISIBLE
        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                progress.visibility = ProgressBar.INVISIBLE
                val container = findViewById<LinearLayout>(R.id.container)
                for (blockSnapshot in dataSnapshot.children) {
                    val blockName = blockSnapshot.key
                    if (blockName != null) {
                        addButtonToContainer(container, blockName)
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                progress.visibility = ProgressBar.INVISIBLE
                // Handle database error
                showDialog("Error", "Error: ${databaseError.message}")
            }
        })
    }
    private fun generateButtons(number: Int, container: LinearLayout) {
        progress.visibility=View.INVISIBLE
        val buttonNames = ('A'..'Z').take(number) // Generate button names from A to Z
        for (name in buttonNames) {
            //buttonNamesList.add("Block$name")
            val button = Button(this)
            button.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            val buttonText = "Block$name"
            button.text = buttonText // Set button text as BlockA, BlockB, etc.
            button.background.setTint(resources.getColor(R.color.pastel_red)) // Set initial color to pastel red

            // Set click listeners for the buttons
            button.setOnClickListener {
                //Toast.makeText(this, "Clicked on $buttonText", Toast.LENGTH_SHORT).show()
                navigate(button.text.toString())
            }

            container.addView(button) // Add button to the container
        }
    }

    private fun addButtonToContainer(container: LinearLayout, blockName: String) {
        val button = Button(this)
        button.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        button.text = blockName // Set button text as block name
        button.setOnClickListener {
            // Handle button click event

           // Toast.makeText(this, "Clicked on $blockName", Toast.LENGTH_SHORT).show()
            navigate(button.text.toString())
        }
        container.addView(button) // Add button to the container
    }

    private fun showDialog(title: String, message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }
        val dialog = builder.create()
        dialog.show()
    }
    private fun navigate(blockButtonName:String) {
        val intent = Intent(this,EachUserPhone::class.java)
        //intent.putExtra("mobilenumber", mobile)
        intent.putExtra("blockbutton", blockButtonName)
        intent.putExtra("mobile",mymobile)
        intent.putExtra("code",buildingcode)
       // intent.putExtra("floors")
       // intent.putExtra("maxunits")
        startActivity(intent)
        finish()
    }
    private fun lightUpButtons(count: Int) {
        val container = findViewById<LinearLayout>(R.id.container)
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i)
            if (child is Button) {
                if (i < count) {
                    // Set button color to green to light up
                    child.background.setTint(resources.getColor(R.color.pastel_green))
                } else {
                    // Set button color to default color to turn off
                    child.background.setTint(resources.getColor(R.color.pastel_red))
                }
            }
        }
    }
}
